package edu.na1.assignment.utils;

public class Constants {

    public static final String IP_ADDRESS = "IPADDRESS";

    public static final String PORT_NUM = "PORTNUM";

    public static final String FILE_FOUND = "FILE_FOUND";

    public static final String STRING_EQUALS = "=";

    public static final String RESULTS_TOKEN = "#";

    public static final String FILE_ABS_PATH = "FILE_ABS_PATH";

    public static final String FILE_NAME = "FILE_NAME";

    public static final String DOWNLOAD_FILE = "DOWNLOAD_FILE";

    public static final String SEARCH_FILE = "SEARCH_FILE";

    public static final String QUIT = "QUIT";

    public static final String YES = "YES";


    public static final String RESULTS = "RESULT";}
